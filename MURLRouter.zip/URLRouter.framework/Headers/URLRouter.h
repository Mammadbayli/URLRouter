//
//  URLRouter.h
//  URLRouter
//
//  Created by Javad Mammadbeyli on 2806//2019.
//  Copyright © 2019 Bank Respublika OJSC. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for URLRouter.
FOUNDATION_EXPORT double URLRouterVersionNumber;

//! Project version string for URLRouter.
FOUNDATION_EXPORT const unsigned char URLRouterVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <URLRouter/PublicHeader.h>


